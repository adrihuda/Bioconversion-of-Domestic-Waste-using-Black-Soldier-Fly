# EM4 Fermentation – Table 1 Dataset

A lightweight Python module that provides **Table 1** (EM4 Inoculant Fermentation Observations) as a tidy `pandas` DataFrame — ready to import into any analysis script or notebook.

---

## Dataset overview

| Panel | Treatment | pH |
|---|---|---|
| EM4 Inoculant | – (inoculant reference) | 3.5 |
| T0 | Control – no EM4 | 6.0 |
| T1 | EM4, 0 days | 5.5 |
| T2 | EM4, 5 days | 4.4 |
| T3 | EM4, 10 days | 3.2 |

Visual observations describe the physical state of the substrate (cabbage + tofu mixture) at each fermentation stage.

---

## Requirements

- Python 3.8+
- pandas

Install dependencies:

```bash
pip install pandas
```

---

## Usage

```python
from load_data import load_table1, get_by_panel

# Load the full table
df = load_table1()
print(df)

# Look up a specific panel
row = get_by_panel(df, "T3")
print(row["pH"])           # 3.2
print(row["Treatment"])    # EM4, 10 days
```

Run the built-in demo:

```bash
python load_data.py
```

---

## File structure

```
.
├── load_data.py   # Dataset + loader functions
└── README.md
```

---

## License

MIT — free to use and adapt with attribution.
