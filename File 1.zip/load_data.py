"""
load_data.py
------------
Load and work with Table 1: EM4 Inoculant Fermentation Observations.

Data columns:
    Panel              - Treatment panel label
    Treatment          - Description of the treatment applied
    Visual_Observation - Description of substrate appearance
    pH                 - Measured pH value
"""

import pandas as pd


# ── Inline dataset ────────────────────────────────────────────────────────────

DATA = [
    {
        "Panel": "EM4 Inoculant",
        "Treatment": "-",
        "Visual_Observation": "-",
        "pH": 3.5,
    },
    {
        "Panel": "T0",
        "Treatment": "Control – no EM4",
        "Visual_Observation": (
            "Fresh mixed substrate appearance — green cabbage clearly visible "
            "with firm texture, white tofu chunks, pale overall color, original "
            "form retained"
        ),
        "pH": 6.0,
    },
    {
        "Panel": "T1",
        "Treatment": "EM4, 0 days",
        "Visual_Observation": (
            "Very similar to T0 — minimal visual difference, original substrate "
            "components still distinguishable, consistent with similar color and smell"
        ),
        "pH": 5.5,
    },
    {
        "Panel": "T2",
        "Treatment": "EM4, 5 days",
        "Visual_Observation": (
            "Yellowish hue developing, substrate components becoming less "
            "distinguishable, texture visibly softer, partial decomposition evident"
        ),
        "pH": 4.4,
    },
    {
        "Panel": "T3",
        "Treatment": "EM4, 10 days",
        "Visual_Observation": (
            "Yellowish hue developing, substrate components becoming less "
            "distinguishable, texture visibly softer, partial decomposition evident"
        ),
        "pH": 3.2,
    },
]


# ── Loader function ───────────────────────────────────────────────────────────

def load_table1() -> pd.DataFrame:
    """
    Return Table 1 as a tidy pandas DataFrame.

    Returns
    -------
    pd.DataFrame
        Columns: Panel, Treatment, Visual_Observation, pH
    """
    df = pd.DataFrame(DATA)
    df["pH"] = pd.to_numeric(df["pH"], errors="coerce")
    return df


# ── Quick-look helpers ────────────────────────────────────────────────────────

def summary(df: pd.DataFrame) -> None:
    """Print a quick summary of the dataset."""
    print("=== Table 1: EM4 Inoculant Fermentation Data ===\n")
    print(df.to_string(index=False))
    print(f"\npH range : {df['pH'].min()} – {df['pH'].max()}")
    print(f"Panels   : {', '.join(df['Panel'].tolist())}")


def get_by_panel(df: pd.DataFrame, panel: str) -> pd.Series:
    """
    Retrieve a single row by panel name (e.g. 'T2').

    Parameters
    ----------
    df : pd.DataFrame
        Output of load_table1().
    panel : str
        Panel identifier, e.g. 'T0', 'T1', 'T2', 'T3', or 'EM4 Inoculant'.

    Returns
    -------
    pd.Series
        The matching row, or raises ValueError if not found.
    """
    result = df[df["Panel"] == panel]
    if result.empty:
        raise ValueError(f"Panel '{panel}' not found. Available: {df['Panel'].tolist()}")
    return result.iloc[0]


# ── Entry point ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    df = load_table1()
    summary(df)

    print("\n--- Example: look up T2 ---")
    row = get_by_panel(df, "T2")
    print(f"Treatment : {row['Treatment']}")
    print(f"pH        : {row['pH']}")
    print(f"Observation: {row['Visual_Observation']}")
